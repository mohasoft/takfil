( function( $ ) {

"use strict";

// *** On ready *** //
$( document ).on( "ready" , function() {

});

// *** On load *** //
$( window ).on( "load" , function() {

});

// *** On resize *** //
$( window ).on( "resize" , function() {

});

// *** On scroll *** //
$( window ).on( "scroll" , function() {

});


// *** jQuery noConflict *** //
var $ = jQuery.noConflict();



// *** Code Starts Here... *** //




} )( jQuery );


